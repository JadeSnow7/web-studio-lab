import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { setTimeout as delay } from 'node:timers/promises';
import { AgentDataError } from './data.js';


async function testDataGate(operationId: string, operation: string, appInstanceId: string) {
  if (appInstanceId !== process.env.WSL_APP_INSTANCE_ID) return;
  const directory = "/tmp/wsl-data-cancel-09d325a5-9b3d-4145-bbbe-40b8b8e2a3ee";
  mkdirSync(directory, { recursive: true });
  writeFileSync(directory + '/entered.json', JSON.stringify({ nonce: "09d325a5-9b3d-4145-bbbe-40b8b8e2a3ee", operationId, operation, appInstanceId, pid: process.pid, at: Date.now() }));
  const started = Date.now();
  while (!existsSync(directory + '/release')) {
    if (Date.now() - started > 180000) throw new Error('Owned live data gate timed out');
    await delay(100);
  }
}

type Operation = 'seed' | 'reset';
type Envelope = { ok: true; data: Record<string, unknown> } | { ok: false; error: { code: string; message: string } };
export interface OperationReceipt {
  operationId: string;
  appInstanceId: string;
  operation: Operation;
  state: 'running' | 'succeeded' | 'failed' | 'cancelled_before_start';
  envelope?: Envelope;
}
interface Entry {
  receipt: OperationReceipt;
  result: Promise<Envelope>;
}
export class OperationError extends Error {
  constructor(
    readonly code: 'operation_conflict' | 'operation_capacity',
    message: string,
  ) {
    super(message);
  }
}

/** Instance-lifetime identities must never be evicted: late requests must not repeat writes. */
export class AgentOperations {
  private readonly entries = new Map<string, Entry>();
  constructor(private readonly appInstanceId: string) {}
  get(id: string) {
    return this.entries.get(id)?.receipt;
  }
  private existing(id: string, operation: Operation) {
    const entry = this.entries.get(id);
    if (entry && entry.receipt.operation !== operation)
      throw new OperationError('operation_conflict', 'Operation ID belongs to another operation');
    return entry;
  }
  private reserve(id: string, operation: Operation, state: OperationReceipt['state']): OperationReceipt {
    if (this.entries.size >= 1024) throw new OperationError('operation_capacity', 'Instance operation registry is full');
    return { operationId: id, appInstanceId: this.appInstanceId, operation, state };
  }
  cancel(id: string, operation: Operation) {
    const entry = this.existing(id, operation);
    if (entry) return entry.receipt;
    const receipt = this.reserve(id, operation, 'cancelled_before_start');
    const envelope: Envelope = { ok: false, error: { code: 'cancelled', message: 'Operation cancelled before start' } };
    receipt.envelope = envelope;
    this.entries.set(id, { receipt, result: Promise.resolve(envelope) });
    return receipt;
  }
  execute(id: string, operation: Operation, work: () => Promise<Record<string, unknown>>): Promise<Envelope> {
    const existing = this.existing(id, operation);
    if (existing) return existing.result;
    const receipt = this.reserve(id, operation, 'running');
    // Defer work until registration is complete, including synchronous failures.
    const result = Promise.resolve()
      .then(async () => { await testDataGate(id, operation, this.appInstanceId); return work(); })
      .then(
        (data): Envelope => {
          receipt.state = 'succeeded';
          return (receipt.envelope = { ok: true, data });
        },
        (error: unknown): Envelope => {
          receipt.state = 'failed';
          return (receipt.envelope = {
            ok: false,
            error: {
              code: error instanceof AgentDataError ? error.code : 'unavailable',
              message: error instanceof Error ? error.message : String(error),
            },
          });
        },
      );
    this.entries.set(id, { receipt, result });
    return result.then((envelope) => {
      if (this.appInstanceId === process.env.WSL_APP_INSTANCE_ID) writeFileSync("/tmp/wsl-data-cancel-09d325a5-9b3d-4145-bbbe-40b8b8e2a3ee/terminal.json", JSON.stringify({ nonce: "09d325a5-9b3d-4145-bbbe-40b8b8e2a3ee", receipt, pid: process.pid, at: Date.now() }));
      return envelope;
    });
  }
}
